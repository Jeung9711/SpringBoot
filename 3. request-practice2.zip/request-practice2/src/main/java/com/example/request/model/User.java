package com.example.request.model;

import lombok.Data;

@Data
public class User {
  Integer age;
  String name;
}
