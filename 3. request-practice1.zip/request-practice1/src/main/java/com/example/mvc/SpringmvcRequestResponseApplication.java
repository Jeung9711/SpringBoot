package com.example.mvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringmvcRequestResponseApplication {
    public static void main(String[] args) {
        SpringApplication.run(SpringmvcRequestResponseApplication.class, args);
    }
}
