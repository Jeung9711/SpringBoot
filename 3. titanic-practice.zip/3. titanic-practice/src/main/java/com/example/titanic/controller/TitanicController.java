package com.example.titanic.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TitanicController {

  @GetMapping("survived")
  public List survived() {
    return null;
  }

  @GetMapping("name")
  public List name() {
    return null;
  }

}
